import pyfiglet
import socket
import customtkinter as ctk
import threading

window1 = ctk.CTk()
window1.title("Port Scanner")
window1.geometry("760x350")

# Printing ascii art "Port Scanner"
ascii = pyfiglet.figlet_format("Port Scanner")
print(ascii)

# Getting the name of host by socket.gethostname() method
host = socket.gethostname()
print("Host Name: ", host)

# gethostnamenbyname() gets the IP Address
# Getting the IP address of the host
ip = socket.gethostbyname(host)
print("Host IP Address: ", ip)

# method/function to scan ports
def scan(): 
    scanLabel.configure(text="Scanning Ports...")
    progressBar.set(0)
    global openPorts
    openPorts = 0
    for port in range(1, 65535):
        try:
            #portScanLabel.configure(text="Scanning port "+str(port))
            
            # socket.socket(socket.family, socket.type)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            
            # connect_ex() connects to IP and current port
            result = s.connect_ex((ip, port))
            
            """ checks if connection is successful, '0' meaning successful connection to port
                connect_ ex() returns an error code, '0' being successful """
            if result == 0:
                print("Port", port, "is open")
                create_port_label(port)
                openPorts = openPorts + 1
                frame3.configure(label_text=str(openPorts)+" Open Ports")
                
                s.settimeout(2)
                try:
                    # Try to receive a banner
                    banner = s.recv(1024).decode('utf-8', errors='ignore')
                    print("port, ", port, ": ", banner.strip())
                    create_banner_label(banner, port)
                except socket.timeout:
                    print("port", port, ": no banner data.")
                    create_nobanner_label(port)
                
                # closes the socket after connection attempt
                s.close()
            
            # Updates progress bar every 257 ports (257 is a factor of 65535)
            if port % 257 == 0:
                progress = port / 65535
                progressBar.set(progress)

        except socket.error:
            # Handle any socket-related errors that occur during the connection attempt
            print("Error obtaining port")
            # Ensure the socket is closed if an error occurs
            s.close()
    scanLabel.configure(text="Scan Complete.")

# functions to create port and banner labels
def create_port_label(port):
    port = str(port)
    portLabel = ctk.CTkLabel(master=frame3, text="Port "+port+" is open", font=("Courier", 12, "bold"), anchor="w", text_color="#ff2b2b")
    portLabel.pack(padx=10, pady=5, anchor="w")
def create_banner_label(banner, port):
    port = str(port)
    bannerLabel = ctk.CTkLabel(master=frame5, text="Port, "+port+": "+banner.strip(), font=("Courier", 12, "bold"), anchor="w")
    bannerLabel.pack(padx=10, pady=5, anchor="w")
def create_nobanner_label(port):
    port = str(port)
    nobannerLabel = ctk.CTkLabel(master=frame5, text="Port "+port+": no banner data.", font=("Courier", 12, "bold"), anchor="w")
    nobannerLabel.pack(padx=10, pady=5, anchor="w")


# widgets
mainFrame = ctk.CTkFrame(window1)
frame1 = ctk.CTkFrame(master=mainFrame, fg_color="#292929", corner_radius=0)
frame2 = ctk.CTkFrame(master=mainFrame, fg_color="#383838", corner_radius=0)
frame4 = ctk.CTkFrame(master=frame2, fg_color="#292929", corner_radius=0)
frame3 = ctk.CTkScrollableFrame(master=frame4, fg_color="#1c1c1c", 
                                corner_radius=2, 
                                scrollbar_button_color="#383838",
                                label_text="Open Ports",
                                width=180)
frame5 = ctk.CTkScrollableFrame(master=frame4, fg_color="#1c1c1c", 
                                corner_radius=2, 
                                scrollbar_button_color="#383838",
                                label_text="Banner Data",
                                width=250)
title = ctk.CTkLabel(master=frame1, text="Port Scanner", font=("Calibri", 24, "bold"))
scanBtn = ctk.CTkButton(master=frame1,
                        text="Scan Ports",
                        font=("Calibri", 12, "bold"),
                        width=100,
                        command=lambda: threading.Thread(target=scan).start() # calling the scan function with threading so it runs with gui
                        )
scanLabel = ctk.CTkLabel(master=frame1, text="", font=("Calibri", 12), anchor="w")
progressBar = ctk.CTkProgressBar(master=frame1, width=100, corner_radius=2, progress_color="green")
portScanLabel = ctk.CTkLabel(master=frame1, text="", font=("Calibri", 8))
hostLabel = ctk.CTkLabel(master=frame2, text="Host: "+host, font=("Calibri", 12, "bold"))
ipLabel = ctk.CTkLabel(master=frame2, text="IP: "+ip, font=("Calibri", 12, "bold"))
quitBtn = ctk.CTkButton(master=frame1, text="Quit", font=("Calibri", 12, "bold"), command=window1.quit, width=90)

# pack widgets
mainFrame.pack(side="left", fill="both", expand=True)
frame1.pack(side="left", fill="y")
frame2.pack(fill="both",expand=True)
title.pack(pady=10, padx=20)
scanBtn.pack(pady=20)
scanLabel.pack(pady=5)
progressBar.pack(pady=0)
progressBar.set(0)
portScanLabel.pack(pady=5)
hostLabel.pack(pady=12, padx=20, anchor="w")
ipLabel.pack(padx=20, anchor="w")
frame4.pack(pady=10, padx=20, side="left")
frame3.pack(pady=10, padx=20, anchor="w", side="left")
frame5.pack(pady=10, padx=20, anchor="w", side="left")
quitBtn.pack(pady=20)

# running window
window1.mainloop()