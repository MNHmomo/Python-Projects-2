import tkinter as tk
from tkinter import ttk, Text
import ttkbootstrap as ttk
import os
import json

fileList = []
json_file = "fileList.json"

# Function to open the text file
def openFile(fileName):
    os.system(f"open {fileName}")

# Function to create buttons for files
def createFileBtn(fileName):
    fileButton = ttk.Button(master=buttonFrame, text=fileName, command=lambda: openFile(fileName))
    fileButton.pack(side="left", padx=10)

# Save file list to a JSON file
def saveFileList():
    with open(json_file, 'w') as f:
        json.dump(fileList, f)

# Load file list from a JSON file
def loadFileList():
    global fileList
    if os.path.exists(json_file):
        with open(json_file, 'r') as f:
            fileList = json.load(f)
        # Create buttons for each file in the fileList
        for fileName in fileList:
            createFileBtn(fileName)

# Function to create a new file and button (without using "with open")
def createFile():
    fileName = entry1.get() + ".txt"
    fileInput = entry2.get("1.0", "end-1c")

    # Open the file manually and write to it
    f = open(fileName, 'w')  # Manually open the file
    f.write(fileInput)        # Write the content
    f.close()                 # Close the file manually
    
    os.system(f"open {fileName}")
    label2.config(text=fileName + " created")
    
    if fileName not in fileList:
        fileList.append(fileName)
        createFileBtn(fileName)
        saveFileList()  # Save the updated file list to JSON

# GUI setup
window1 = ttk.Window(themename='darkly')
window1.geometry("800x500")

title = ttk.Label(window1, 
                  text="Create a '.txt' file.", 
                  font="Arial 24 bold", 
                  padding=(0,20,0,0))

inputFrame1 = ttk.Frame(window1)
inputFrame2 = ttk.Frame(window1)
buttonFrame = ttk.Frame(window1)  # Frame for buttons

label1 = ttk.Label(master=inputFrame1, 
                   text="File Name", 
                   font="Arial 12", 
                   background='#83a6f7', 
                   padding=6, 
                   width="8", 
                   anchor="center")

entry1 = ttk.Entry(master=inputFrame1, width="20")
button1 = ttk.Button(master=inputFrame2, 
                   text="Create", 
                   padding=6, 
                   width="20", 
                   command=createFile)

entry2 = ttk.Text(master=inputFrame2, width="20", height="10")
label2 = ttk.Label(window1, text="")

quitBtn = ttk.Button(window1, text="Quit", command=window1.quit)

# Packing all widgets
title.pack()
label1.pack(side='left', padx=0)
entry1.pack(side='left')
button1.pack(side='bottom', padx=0)
entry2.pack(side='top')

# Pack the frames
inputFrame1.pack(pady=8)
inputFrame2.pack(pady=8)
buttonFrame.pack(pady=8)  # New frame for buttons

label2.pack()
quitBtn.pack()

# Load the file list and recreate buttons at startup
loadFileList()

window1.mainloop()
