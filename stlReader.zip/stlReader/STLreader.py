import pyvista as pv
pv.set_plot_theme("default") #dark, paraview, document
import tkinter as tk
import ttkbootstrap as ttk
from tkinter import filedialog
from PIL import Image, ImageTk
import threading

def openSTL(mesh_style=None, color_style=None):
    stlPath = entry1.get()
    if stlPath:  # Ensure that the file path is not empty
        mesh = pv.read(stlPath)
        if mesh_style is None and color_style is None:
            mesh_style = mesh_options_combobox.get()  # Get the mesh type from the combobox
            color_style = color_options_combobox.get()  # Get the color from the combobox
        if checkType(mesh_style, color_style):
            # Create a Plotter object
            plotMesh(mesh, mesh_style, color_style)
   
# Plots mesh with pyvista, creates pyvista window
def plotMesh(mesh, mesh_style, color_style):
    plotter = pv.Plotter(off_screen=False)  # Use off-screen rendering (not)
    plotter.add_mesh(mesh, color=color_style, style=mesh_style)
    legend(plotter, mesh_style)
    plotter.show()
            
# Adds a legend to pyvista window, shows mesh type
def legend(plotter, mesh_style):
    plotter.add_legend(
        labels=mesh_style,
        border=False, 
        size=(0.1, 0.3), 
        loc='upper left', 
        font_family="courier", 
        background_opacity=1.0,
    )

# Function to load STL file and show preview
def loadSTL(mesh_style=None, color_style=None):
    stlPath = entry1.get()
    if stlPath:  # Ensure that the file path is not empty
        # Load the STL file
        mesh = pv.read(stlPath)
        # If mesh_style is not provided, get it from the combobox
        if mesh_style is None and color_style is None:
            mesh_style = mesh_options_combobox.get()  # Get the mesh type from the combobox
            color_style = color_options_combobox.get()  # Get the color from the combobox
        if checkType(mesh_style, color_style): # Checks if mesh type, color are valid
            # Create a Plotter object
            plotter = pv.Plotter(off_screen=True)  # Use off-screen rendering
            screenshot(plotter, mesh, mesh_style, color_style) # Calls screenshot function
        else:
            print("Choose a valid mesh type and color.")
            button_load_stl.configure(state="disabled")
            label2.configure(text="Select a valid mesh type and color.")
            label2.after(2000, lambda: label2.configure(text=""))

# Function to show preview
def screenshot(plotter, mesh, mesh_style, color_style):
    plotter.add_mesh(mesh, color=color_style, style=mesh_style)
            
    # Capture screenshot of the plotter as an image
    screenshot_path = 'preview.png'
    plotter.show(auto_close=False, screenshot=screenshot_path)

    # Open the image with PIL and display it in the tkinter window
    img = Image.open(screenshot_path)
    img.thumbnail((300, 300))  # Resize the image for the tkinter window
    img_tk = ImageTk.PhotoImage(img)

    # Update the label with the new image
    preview_label.config(image=img_tk)
    preview_label.image = img_tk  # Keep a reference to avoid garbage collection
    button_load_stl.configure(state="enabled")

# Checks if mesh type, color are valid
def checkType(mesh_style, color_style):
    if mesh_style in mesh_options_values and color_style in color_options_values:
        return True
    else:
        return False

# Function to open file dialog and select an STL file
def select_stl_file():
    file_path = filedialog.askopenfilename(
        filetypes=[("STL files", "*.stl")],  # Filter for STL files only
        title="Select an STL file"
    )
    if file_path:  # If a file is selected, update the entry widget
        entry1.delete(0, tk.END)
        entry1.insert(0, file_path)
        loadSTL()

# updated preview mesh after every change
def update_mesh(event=None):
    loadSTL()

# Create the main window
window1 = ttk.Window(themename='darkly')
window1.title("STL Viewer")
window1.geometry("550x400")
window1.iconbitmap("icon.ico")

# Create widgets
label1 = ttk.Label(window1, text="Select your STL file or paste the path below:")
entry1 = ttk.Entry(window1, width="30")
frame1 = ttk.Frame(window1)
frame2 = ttk.Frame(master=frame1)
button_select_file = ttk.Button(master=frame2, text="Select File", width="12", command=select_stl_file)
button_load_stl = ttk.Button(master=frame2, text="Open STL", width="12", command=openSTL, state="disabled")
preview_label = ttk.Label(master=frame1)
label2 = ttk.Label(master=window1, text="")

# Customization Menus
mesh_options_values = [
    "surface",
    "wireframe",
    "points",
]

color_options_values = [
    "black",
    "white",
    "red",
    "green",
    "blue",
    "yellow",
    "cyan",
    "magenta",
    "orange",
    "purple",
    "brown",
    "grey",
]

mesh_options_combobox = ttk.Combobox(master=frame2, values=mesh_options_values, width="12")
color_options_combobox = ttk.Combobox(master=frame2, values=color_options_values, width="12")



# Pack widgets
label1.pack(pady=10)
entry1.pack(pady=5)
button_select_file.pack(padx=10, pady=5)
button_load_stl.pack(pady=5, padx=5)

mesh_options_combobox.pack(pady=5, padx=5)
mesh_options_combobox.set("Select Mesh Type")
mesh_options_combobox.bind("<<ComboboxSelected>>", update_mesh)

color_options_combobox.pack(pady=5, padx=5)
color_options_combobox.set("Select Color")
color_options_combobox.bind("<<ComboboxSelected>>", update_mesh)

preview_label.pack(side="right", pady=10)  # Add the preview label to the window
frame1.pack()
frame2.pack(side="left")
label2.pack(pady=5)

# Start the Tkinter main loop
window1.mainloop()
